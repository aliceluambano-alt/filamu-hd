# Filamu HD – A. C. Luambano

Orodha ya filamu mpya zilizotolewa rasmi.  
Tazama trailer au utafute full movie kwenye YouTube. Kwa ubora wa HD tumia majukwaa rasmi (Netflix, Disney+, Showmax n.k.).

## Vipengele
- Filters: Eneo (Marekani, Ulaya, Korea, Tanzania, Afrika, India, Asia...)
- Aina & Umri (Dini, PG, 13+, 16+, 18+)
- Filamu za Tanzania + filamu maarufu za kimataifa
- Utafutaji wa haraka
- Filamu mpya huongezwa **kiotomatiki** kila unapofungua site (kutoka TMDB)
- Taarifa inaonyeshwa: **ngapi filamu mpya zimeongezwa**
- Filamu mpya zina alama ya kijani **MPYA**

## Jinsi ya kuweka API Key ya TMDB (ili filamu mpya zijiongeze)

1. Nenda: https://www.themoviedb.org/settings/api  
2. Fungua akaunti (bure) na omba **API Key**
3. Fungua faili `index.html`
4. Tafuta mstari huu:
   ```js
   const TMDB_API_KEY = "YOUR_TMDB_API_KEY";
   ```
5. Badilisha na key yako:
   ```js
   const TMDB_API_KEY = "weka_key_yako_hapa";
   ```

**Usiiache API key wazi kwenye GitHub ya umma.**

## Deploy kwenye GitHub Pages

1. Unda repository mpya (mfano: `filamu-hd`)
2. Upload faili `index.html` na `README.md`
3. Nenda **Settings → Pages**
4. Source: Deploy from a branch → `main` → `/ (root)`
5. Bofya **Save**
6. Site itakuwa live baada ya dakika chache:  
   `https://USERNAME.github.io/filamu-hd`

---

© 2026 A. C. Luambano  
This product uses the TMDB API but is not endorsed or certified by TMDB.
